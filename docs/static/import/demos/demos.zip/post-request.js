client.global.set("BONOBO", response.headers.valueOf("Date"));
